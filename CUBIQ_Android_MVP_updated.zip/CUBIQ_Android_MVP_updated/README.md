# CUBIQ Android MVP

Versión actualizada: el formulario de publicación ya no usa emojis como icono. Cada creador puede seleccionar una imagen JPG, PNG o WebP para usarla como portada del addon. La portada se muestra en la tarjeta y en los detalles.

Esta versión sigue siendo un MVP local. Para publicaciones compartidas entre usuarios se necesita backend, autenticación, base de datos y almacenamiento en la nube.
